//: Playground -un lugar donde practicar

import UIKit


//:Asignación de valor mutable
var variable = "esto es Swift"
 
 




//:Asignación de valor inmutable
 let constante = 4

//: Asignación formal (definiendo el tipo de dato)
var cadena:String = String()

cadena = "Hola mundo " + variable
print("El contenido es: \(cadena)")
print("El valor de constente es: \(constante)")





